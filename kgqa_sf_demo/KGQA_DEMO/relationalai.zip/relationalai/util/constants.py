
TOP_LEVEL_PROFILE_NAME = "__top_level__"
PARTIAL_PROFILE_NAME = "__partial__"
DEFAULT_PROFILE_NAME = "default"